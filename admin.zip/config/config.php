<?php
// Site Configuration
define('SITE_NAME', 'AuctionNova');
define('SITE_URL', 'http://localhost/Auction%20nova%202/');
define('SITE_EMAIL', 'admin@auctionnova.com');

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'auction_nova');
define('DB_USER', 'root');
define('DB_PASS', '');

// Security
define('HASH_ALGO', PASSWORD_DEFAULT);
define('SESSION_TIMEOUT', 3600); // 1 hour

// Auction Settings
define('MIN_BID_INCREMENT', 50); // Minimum bid increment in rupees
define('MAX_AUCTION_DURATION', 7); // Maximum auction duration in days
define('MIN_AGE_REQUIREMENT', 18); // Minimum age for registration

// File Upload Settings
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif']);
define('UPLOAD_PATH', 'uploads/');

// Email Settings (for future implementation)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
