<?php
header('Content-Type: application/json');
require_once '../includes/functions.php';

if (!isset($_GET['auction_id']) || !is_numeric($_GET['auction_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid auction ID']);
    exit;
}

$auction_id = (int)$_GET['auction_id'];

try {
    $db = new Database();
    $conn = $db->connect();
    
    // Get auction info
    $auction_query = "SELECT current_price, min_increment, status, end_time FROM auctions WHERE id = ?";
    $auction_stmt = $conn->prepare($auction_query);
    $auction_stmt->execute([$auction_id]);
    $auction = $auction_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$auction) {
        echo json_encode(['success' => false, 'message' => 'Auction not found']);
        exit;
    }
    
    // Get bid count
    $bid_count_query = "SELECT COUNT(*) as count FROM bids WHERE auction_id = ?";
    $bid_count_stmt = $conn->prepare($bid_count_query);
    $bid_count_stmt->execute([$auction_id]);
    $bid_count = $bid_count_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Get latest bids
    $bids_query = "SELECT b.bid_amount, b.bid_time, u.username 
                   FROM bids b 
                   JOIN users u ON b.bidder_id = u.id 
                   WHERE b.auction_id = ? 
                   ORDER BY b.bid_time DESC 
                   LIMIT 10";
    $bids_stmt = $conn->prepare($bids_query);
    $bids_stmt->execute([$auction_id]);
    $latest_bids = $bids_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'current_price' => $auction['current_price'],
        'min_increment' => $auction['min_increment'],
        'bid_count' => $bid_count,
        'latest_bids' => $latest_bids,
        'status' => $auction['status'],
        'end_time' => $auction['end_time']
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
