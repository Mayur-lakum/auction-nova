<?php
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect(SITE_URL . 'user/dashboard.php');
}

$page_title = 'Login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid request. Please try again.';
    } else {
        $email = sanitize_input($_POST['email']);
        $password = $_POST['password'];
        
        if (empty($email) || empty($password)) {
            $error = 'Please fill in all fields.';
        } else {
            $db = Database::getInstance();
            $conn = $db->getConnection();
            
            $query = "SELECT id, username, email, password, role, is_active, is_verified FROM users WHERE email = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                if (!$user['is_active']) {
                    $error = 'Your account has been deactivated. Please contact support.';
                } else {
                    // Set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['is_verified'] = $user['is_verified'];
                    
                    // Update last login
                    $update_query = "UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = ?";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->execute([$user['id']]);
                    
                    flash_message('success', 'Welcome back, ' . $user['username'] . '!');
                    
                    // Redirect based on user role
                    if ($user['role'] === 'admin' || $user['role'] === 'super_admin') {
                        $redirect_url = $_SESSION['redirect_after_login'] ?? SITE_URL . 'admin/index.php';
                    } else {
                        $redirect_url = $_SESSION['redirect_after_login'] ?? SITE_URL . 'user/dashboard.php';
                    }
                    unset($_SESSION['redirect_after_login']);
                    redirect($redirect_url);
                }
            } else {
                $error = 'Invalid email or password.';
            }
        }
    }
}

include '../includes/header.php';
?>

<div class="min-vh-100 d-flex align-items-center" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); background-attachment: fixed;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card border-0 shadow-lg" style="border-radius: 25px; backdrop-filter: blur(15px); background: rgba(255, 255, 255, 0.9); border: 1px solid rgba(255, 255, 255, 0.2);">
                    <div class="card-body p-5">
                        <!-- Logo/Brand Section -->
                        <div class="text-center mb-5">
                            <div class="mb-4">
                                <div class="d-inline-flex align-items-center justify-content-center rounded-circle shadow-lg" 
                                     style="width: 90px; height: 90px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                    <i class="fas fa-gavel fa-2x text-white"></i>
                                </div>
                            </div>
                            <h2 class="fw-bold mb-2" style="color: #2d3748;">Welcome Back</h2>
                            <p class="text-muted" style="color: #718096;">Sign in to your <?php echo SITE_NAME; ?> account</p>
                        </div>
                    
                    <?php if ($error): ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <!-- Enhanced Form Fields -->
                        <div class="mb-4">
                            <label for="email" class="form-label fw-semibold" style="color: #2d3748;">Email Address</label>
                            <div class="position-relative">
                                <div class="position-absolute top-50 start-0 translate-middle-y ms-3 text-muted">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <input type="email" class="form-control form-control-lg ps-5" id="email" name="email" 
                                       placeholder="Enter your email address"
                                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                                       style="border-radius: 15px; border: 2px solid #e2e8f0; transition: all 0.3s ease; background: rgba(255, 255, 255, 0.8);"
                                       required>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="password" class="form-label fw-semibold" style="color: #2d3748;">Password</label>
                            <div class="position-relative">
                                <div class="position-absolute top-50 start-0 translate-middle-y ms-3 text-muted">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <input type="password" class="form-control form-control-lg ps-5 pe-5" id="password" name="password" 
                                       placeholder="Enter your password"
                                       style="border-radius: 15px; border: 2px solid #e2e8f0; transition: all 0.3s ease; background: rgba(255, 255, 255, 0.8);"
                                       required>
                                <button class="btn position-absolute top-50 end-0 translate-middle-y me-3 p-0 border-0 bg-transparent text-muted" 
                                        type="button" id="togglePassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-primary btn-lg w-100 fw-semibold">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                Login as User
                            </button>
                        </div>
                        
                        <div class="text-center mb-3">
                            <span class="text-muted">or</span>
                        </div>
                        
                        <div class="d-grid mb-3">
                            <a href="<?php echo SITE_URL; ?>admin/login.php" class="btn btn-outline-dark btn-lg w-100 fw-semibold">
                                <i class="fas fa-shield-alt me-2"></i>
                                Login as Admin
                            </a>
                        </div>
                        
                        <!-- Remember Me & Forgot Password -->
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember" 
                                       style="border-radius: 6px;">
                                <label class="form-check-label" for="remember" style="color: #718096;">
                                    Remember me
                                </label>
                            </div>
                            <a href="forgot-password.php" class="text-decoration-none fw-semibold" style="color: #667eea;">
                                Forgot Password?
                            </a>
                        </div>
                        
                        <!-- Enhanced Login Button -->
                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-lg fw-bold text-white" 
                                    style="border-radius: 15px; padding: 15px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);">
                                <i class="fas fa-sign-in-alt me-2"></i>Sign In
                            </button>
                        </div>
                    </form>
                    
                    <!-- Divider -->
                    <div class="text-center mb-4">
                        <div class="position-relative">
                            <hr class="my-4">
                            <span class="position-absolute top-50 start-50 translate-middle bg-white px-3" style="color: #718096;" small>
                                or
                            </span>
                        </div>
                    </div>
                    
                    <!-- Social Login Options (Optional) -->
                    <div class="d-grid gap-2 mb-4">
                        <button type="button" class="btn btn-lg" 
                                style="border-radius: 15px; padding: 12px; background: rgba(255, 255, 255, 0.8); border: 2px solid #e2e8f0; color: #4a5568; transition: all 0.3s ease;">
                            <i class="fab fa-google me-2" style="color: #ea4335;"></i>Continue with Google
                        </button>
                    </div>
                    
                    <!-- Sign Up Link -->
                    <div class="text-center">
                        <p class="mb-0" style="color: #718096;">
                            Don't have an account? 
                            <a href="register.php" class="text-decoration-none fw-bold" style="color: #667eea;">
                                Create Account
                            </a>
                        </p>
                    </div>
                    
                    <!-- Admin Quick Login (for testing) -->
                    <div class="text-center mt-4 pt-3 border-top">
                        <small class="muted" style="color: #a0aec0;">
                            <strong>Quick Admin Login:</strong> admin@auctionnova.com / admin123
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Custom CSS for Enhanced Login -->
<style>
/* Input Focus Effects */
.form-control:focus {
    border-color: #667eea !important;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25) !important;
    transform: translateY(-2px);
    background: rgba(255, 255, 255, 0.95) !important;
}

/* Button Hover Effects */
.btn-lg:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6) !important;
}

.btn-lg:hover:not(.btn-primary) {
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15) !important;
    background: rgba(255, 255, 255, 0.95) !important;
}

/* Card Animation */
.card {
    animation: slideUp 0.6s ease-out;
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Logo Animation */
.rounded-circle {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
    }
    70% {
        box-shadow: 0 0 0 10px rgba(0, 123, 255, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(0, 123, 255, 0);
    }
}

/* Background Animation */
body {
    background-attachment: fixed;
}

/* Alert Enhancement */
.alert {
    border-radius: 15px;
    border: none;
    animation: slideDown 0.3s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
    .card-body {
        padding: 2rem !important;
    }
    
    .rounded-circle {
        width: 60px !important;
        height: 60px !important;
    }
    
    .rounded-circle i {
        font-size: 1.5rem !important;
    }
}
</style>

<script>
// Toggle password visibility with animation
document.getElementById('togglePassword').addEventListener('click', function() {
    const password = document.getElementById('password');
    const icon = this.querySelector('i');
    
    if (password.type === 'password') {
        password.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        password.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
});

// Form validation with visual feedback
document.querySelector('form').addEventListener('submit', function(e) {
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    let isValid = true;
    
    // Reset previous validation styles
    email.classList.remove('is-invalid');
    password.classList.remove('is-invalid');
    
    // Email validation
    if (!email.value || !email.value.includes('@')) {
        email.classList.add('is-invalid');
        isValid = false;
    }
    
    // Password validation
    if (!password.value || password.value.length < 3) {
        password.classList.add('is-invalid');
        isValid = false;
    }
    
    if (!isValid) {
        e.preventDefault();
        // Add shake animation to card
        document.querySelector('.card').style.animation = 'shake 0.5s ease-in-out';
        setTimeout(() => {
            document.querySelector('.card').style.animation = 'slideUp 0.6s ease-out';
        }, 500);
    }
});

// Add shake animation for validation errors
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    
    .is-invalid {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
    }
`;
document.head.appendChild(style);

// Auto-fill admin credentials (for testing)
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('admin') === 'true') {
        document.getElementById('email').value = 'admin@auctionnova.com';
        document.getElementById('password').value = 'admin123';
    }
});
</script>

<?php include '../includes/footer.php'; ?>
