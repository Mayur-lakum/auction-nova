<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

// Security functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function is_admin() {
    return isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin');
}

// require_login() function is defined in auth.php

function require_admin() {
    if (!is_admin()) {
        header('Location: ' . SITE_URL . 'index.php');
        exit();
    }
}

// Utility functions
function time_ago($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'just now';
    if ($time < 3600) return floor($time/60) . ' minutes ago';
    if ($time < 86400) return floor($time/3600) . ' hours ago';
    if ($time < 2592000) return floor($time/86400) . ' days ago';
    if ($time < 31536000) return floor($time/2592000) . ' months ago';
    
    return floor($time/31536000) . ' years ago';
}

function format_currency($amount) {
    return '₹' . number_format($amount, 2);
}

function time_remaining($end_time) {
    $now = time();
    $end = strtotime($end_time);
    $diff = $end - $now;
    
    if ($diff <= 0) {
        return 'Auction ended';
    }
    
    $days = floor($diff / 86400);
    $hours = floor(($diff % 86400) / 3600);
    $minutes = floor(($diff % 3600) / 60);
    
    if ($days > 0) {
        return $days . 'd ' . $hours . 'h ' . $minutes . 'm';
    } elseif ($hours > 0) {
        return $hours . 'h ' . $minutes . 'm';
    } else {
        return $minutes . 'm';
    }
}

function upload_image($file, $directory = 'uploads/') {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    $allowed_types = ALLOWED_IMAGE_TYPES;
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_types)) {
        return false;
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return false;
    }
    
    $filename = uniqid() . '.' . $file_extension;
    $upload_path = $directory . $filename;
    
    if (!file_exists($directory)) {
        mkdir($directory, 0755, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        return $filename;
    }
    
    return false;
}

function send_notification($user_id, $type, $title, $message, $auction_id = null) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $query = "INSERT INTO notifications (user_id, type, title, message, auction_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    return $stmt->execute([$user_id, $type, $title, $message, $auction_id]);
}

function get_user_notifications($user_id, $limit = 10) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Ensure limit is an integer and safe
    $limit = (int)$limit;
    $query = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function mark_notification_read($notification_id) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $query = "UPDATE notifications SET is_read = TRUE WHERE id = ?";
    $stmt = $conn->prepare($query);
    return $stmt->execute([$notification_id]);
}

function log_admin_action($admin_id, $action, $target_type, $target_id = null, $description = null) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
    
    $query = "INSERT INTO admin_logs (admin_id, action, target_type, target_id, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    return $stmt->execute([$admin_id, $action, $target_type, $target_id, $description, $ip_address]);
}

function redirect($url) {
    header('Location: ' . $url);
    exit();
}

function flash_message($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash_messages() {
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function validate_age($date_of_birth) {
    $today = new DateTime();
    $dob = new DateTime($date_of_birth);
    $age = $today->diff($dob)->y;
    return $age >= MIN_AGE_REQUIREMENT;
}

function is_auction_active($auction) {
    return $auction['status'] === 'active' && strtotime($auction['end_time']) > time();
}

function can_bid($auction, $user_id) {
    return is_auction_active($auction) && $auction['seller_id'] != $user_id;
}
?>
