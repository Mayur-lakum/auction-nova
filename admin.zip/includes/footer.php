    </main>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5 class="fw-bold mb-3">
                        <i class="fas fa-gavel me-2"></i><?php echo SITE_NAME; ?>
                    </h5>
                    <p class="text-muted">
                        Your trusted online auction platform. Discover unique items, 
                        place bids, and win amazing deals from sellers worldwide.
                    </p>
                    <div class="social-links">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(SITE_URL); ?>" class="text-light me-3" target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(SITE_URL); ?>&text=<?php echo urlencode(SITE_NAME); ?>" class="text-light me-3" target="_blank" rel="noopener noreferrer" aria-label="Share on X"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/" class="text-light me-3" target="_blank" rel="noopener noreferrer" aria-label="Open Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo urlencode(SITE_URL); ?>" class="text-light" target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="fw-bold mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo SITE_URL; ?>" class="text-muted text-decoration-none">Home</a></li>
                        <li><a href="<?php echo SITE_URL; ?>auctions/" class="text-muted text-decoration-none">Browse Auctions</a></li>
                        <li><a href="<?php echo SITE_URL; ?>seller/create-auction.php" class="text-muted text-decoration-none">Sell Item</a></li>
                        <li><a href="<?php echo SITE_URL; ?>pages/how-it-works.php" class="text-muted text-decoration-none">How It Works</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="fw-bold mb-3">Categories</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo SITE_URL; ?>auctions/?category=1" class="text-muted text-decoration-none">Electronics</a></li>
                        <li><a href="<?php echo SITE_URL; ?>auctions/?category=2" class="text-muted text-decoration-none">Vehicles</a></li>
                        <li><a href="<?php echo SITE_URL; ?>auctions/?category=3" class="text-muted text-decoration-none">Antiques</a></li>
                        <li><a href="<?php echo SITE_URL; ?>auctions/?category=4" class="text-muted text-decoration-none">Jewelry</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="fw-bold mb-3">Support</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo SITE_URL; ?>pages/faq.php" class="text-muted text-decoration-none">FAQ</a></li>
                        <li><a href="<?php echo SITE_URL; ?>pages/contact.php" class="text-muted text-decoration-none">Contact Us</a></li>
                        <li><a href="<?php echo SITE_URL; ?>pages/terms.php" class="text-muted text-decoration-none">Terms of Service</a></li>
                        <li><a href="<?php echo SITE_URL; ?>pages/privacy.php" class="text-muted text-decoration-none">Privacy Policy</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="fw-bold mb-3">Contact Info</h6>
                    <ul class="list-unstyled text-muted">
                        <li><i class="fas fa-envelope me-2"></i><?php echo SITE_EMAIL; ?></li>
                        <li><i class="fas fa-phone me-2"></i>+91 98765 43210</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i>Mumbai, India</li>
                    </ul>
                </div>
            </div>
            
            <hr class="my-4">
            
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="text-muted mb-0">
                        &copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="text-muted mb-0">
                        Made with <i class="fas fa-heart text-danger"></i> in India
                    </p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo SITE_URL; ?>assets/js/main.js"></script>
    
    <!-- Page-specific scripts -->
    <?php if (isset($page_scripts)): ?>
        <?php foreach ($page_scripts as $script): ?>
            <script src="<?php echo SITE_URL . $script; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
