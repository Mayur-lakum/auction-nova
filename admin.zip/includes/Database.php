<?php
/**
 * Database Connection Class
 * Provides a singleton database connection with PDO
 */

// Only include config if not already included
if (!defined('DB_HOST') && file_exists(__DIR__ . '/../config/config.php')) {
    require_once __DIR__ . '/../config/config.php';
}

// Check if class already exists
if (!class_exists('Database')) {

    class Database {
        private static $instance = null;
        private $conn = null;

        // Private constructor to prevent direct instantiation
        private function __construct() {
            try {
                $this->conn = new PDO(
                    'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                    DB_USER,
                    DB_PASS,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ]
                );
            } catch (PDOException $e) {
                error_log('Database Connection Error: ' . $e->getMessage());
                throw new Exception('Unable to connect to the database. Please try again later.');
            }
        }

        // Get the database connection instance
        public static function getInstance() {
            if (self::$instance === null) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        // Get the PDO connection
        public function getConnection() {
            return $this->conn;
        }

        // Execute a query with parameters
        public function query($sql, $params = []) {
            try {
                $stmt = $this->conn->prepare($sql);
                $stmt->execute($params);
                return $stmt;
            } catch (PDOException $e) {
                error_log('Query Error: ' . $e->getMessage() . '\nSQL: ' . $sql);
                throw new Exception('Database error occurred. Please try again.');
            }
        }

        // Get single row
        public function fetch($sql, $params = []) {
            return $this->query($sql, $params)->fetch();
        }

        // Get all rows
        public function fetchAll($sql, $params = []) {
            return $this->query($sql, $params)->fetchAll();
        }

        // Get single value
        public function fetchColumn($sql, $params = []) {
            return $this->query($sql, $params)->fetchColumn();
        }

        // Get last insert ID
        public function lastInsertId() {
            return $this->conn->lastInsertId();
        }

        // Begin transaction
        public function beginTransaction() {
            return $this->conn->beginTransaction();
        }

        // Commit transaction
        public function commit() {
            return $this->conn->commit();
        }

        // Rollback transaction
        public function rollBack() {
            return $this->conn->rollBack();
        }

        // Prevent cloning of the instance
        private function __clone() {}

        // Prevent unserialization of the instance
        public function __wakeup() {
            throw new Exception("Cannot unserialize a singleton.");
        }
    }
}
