<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin authentication check
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'super_admin'])) {
    header('Location: login.php');
    exit();
}

// Handle category actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_category') {
        $name = sanitize_input($_POST['name'] ?? '');
        $description = sanitize_input($_POST['description'] ?? '');
        
        if (!empty($name)) {
            $db = Database::getInstance();
            $db->query("INSERT INTO categories (name, description, created_at) VALUES (?, ?, NOW())", [$name, $description]);
            header('Location: manage-categories.php?success=Category added');
            exit();
        }
    } elseif ($action === 'edit_category') {
        $id = intval($_POST['id'] ?? 0);
        $name = sanitize_input($_POST['name'] ?? '');
        $description = sanitize_input($_POST['description'] ?? '');
        
        if ($id > 0 && !empty($name)) {
            $db = Database::getInstance();
            $db->query("UPDATE categories SET name = ?, description = ? WHERE id = ?", [$name, $description, $id]);
            header('Location: manage-categories.php?success=Category updated');
            exit();
        }
    } elseif ($action === 'delete_category') {
        $id = intval($_POST['id'] ?? 0);
        
        if ($id > 0) {
            $db = Database::getInstance();
            $db->query("DELETE FROM categories WHERE id = ?", [$id]);
            header('Location: manage-categories.php?success=Category deleted');
            exit();
        }
    }
}

// Get categories
$db = Database::getInstance();
$categories = $db->fetchAll("
    SELECT c.*, 
           (SELECT COUNT(*) FROM auctions WHERE category_id = c.id) as auction_count
    FROM categories c 
    ORDER BY c.name
");

$page_title = 'Manage Categories';
require_once '../includes/header.php';
?>

<style>
.category-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.category-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.category-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 12px;
}

.category-name {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 4px;
}

.category-stats {
    display: flex;
    gap: 20px;
    margin-bottom: 12px;
}

.stat-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9rem;
    color: #4a5568;
}

.stat-number {
    font-weight: 600;
    color: #2d3748;
}

.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn-sm {
    padding: 6px 12px;
    font-size: 0.8rem;
    border-radius: 6px;
}

.add-category-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 12px;
    padding: 30px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px dashed rgba(255,255,255,0.3);
}

.add-category-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 30px;
    border-radius: 12px;
    width: 500px;
    max-width: 90%;
}
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Manage Categories</h1>
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($_GET['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- Add Category Card -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="add-category-card" onclick="showAddModal()">
                        <i class="fas fa-plus fa-2x mb-3"></i>
                        <h4>Add New Category</h4>
                        <p>Click to create a new auction category</p>
                    </div>
                </div>

                <!-- Categories List -->
                <?php if (!empty($categories)): ?>
                    <?php foreach ($categories as $category): ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="category-card">
                                <div class="category-header">
                                    <div>
                                        <div class="category-name"><?php echo htmlspecialchars($category['name']); ?></div>
                                        <div class="text-muted"><?php echo htmlspecialchars($category['description'] ?: 'No description'); ?></div>
                                    </div>
                                </div>
                                
                                <div class="category-stats">
                                    <div class="stat-item">
                                        <i class="fas fa-gavel"></i>
                                        <span class="stat-number"><?php echo $category['auction_count']; ?></span>
                                        <span>Auctions</span>
                                    </div>
                                    <div class="stat-item">
                                        <i class="fas fa-calendar"></i>
                                        <span>Created <?php echo time_ago($category['created_at']); ?></span>
                                    </div>
                                </div>
                                
                                <div class="action-buttons">
                                    <button class="btn btn-info btn-sm" onclick="viewCategory(<?php echo $category['id']; ?>)">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    <button class="btn btn-warning btn-sm" onclick="showEditModal(<?php echo $category['id']; ?>, '<?php echo htmlspecialchars($category['name']); ?>', '<?php echo htmlspecialchars($category['description'] ?? ''); ?>')">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <?php if ($category['auction_count'] == 0): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this category?');">
                                            <input type="hidden" name="action" value="delete_category">
                                            <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-danger btn-sm" disabled title="Cannot delete category with auctions">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="text-center py-5">
                            <i class="fas fa-tags fa-3x text-muted mb-3"></i>
                            <h4>No categories found</h4>
                            <p class="text-muted">Create your first category to organize auctions.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Category Modal -->
<div id="addModal" class="modal">
    <div class="modal-content">
        <h4>Add New Category</h4>
        <form method="POST">
            <input type="hidden" name="action" value="add_category">
            
            <div class="mb-3">
                <label for="name" class="form-label">Category Name *</label>
                <input type="text" class="form-control" name="name" id="name" required>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" name="description" id="description" rows="3"></textarea>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Add Category</button>
                <button type="button" class="btn btn-secondary" onclick="hideAddModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Category Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <h4>Edit Category</h4>
        <form method="POST">
            <input type="hidden" name="action" value="edit_category">
            <input type="hidden" name="id" id="editId">
            
            <div class="mb-3">
                <label for="editName" class="form-label">Category Name *</label>
                <input type="text" class="form-control" name="name" id="editName" required>
            </div>
            
            <div class="mb-3">
                <label for="editDescription" class="form-label">Description</label>
                <textarea class="form-control" name="description" id="editDescription" rows="3"></textarea>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Update Category</button>
                <button type="button" class="btn btn-secondary" onclick="hideEditModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showAddModal() {
    document.getElementById('addModal').style.display = 'block';
}

function hideAddModal() {
    document.getElementById('addModal').style.display = 'none';
}

function showEditModal(id, name, description) {
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editDescription').value = description;
    document.getElementById('editModal').style.display = 'block';
}

function hideEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function viewCategory(categoryId) {
    // This could show auctions in this category
    window.location.href = 'manage-auctions.php?category=' + categoryId;
}

// Close modals when clicking outside
document.getElementById('addModal').addEventListener('click', function(e) {
    if (e.target === this) hideAddModal();
});

document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) hideEditModal();
});
</script>

<?php require_once '../includes/footer.php'; ?>
