<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin authentication check
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'super_admin'])) {
    header('Location: login.php');
    exit();
}

// Handle report actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $report_id = intval($_POST['report_id'] ?? 0);
    
    if ($action === 'resolve_report' && $report_id > 0) {
        $resolution = sanitize_input($_POST['resolution'] ?? '');
        $db = Database::getInstance();
        $db->query("UPDATE reports SET status = 'resolved', resolution = ?, resolved_at = NOW(), resolved_by = ? WHERE id = ?", 
                  [$resolution, $_SESSION['user_id'], $report_id]);
        header('Location: manage-reports.php?success=Report resolved');
        exit();
    } elseif ($action === 'dismiss_report' && $report_id > 0) {
        $db = Database::getInstance();
        $db->query("UPDATE reports SET status = 'dismissed', resolved_at = NOW(), resolved_by = ? WHERE id = ?", 
                  [$_SESSION['user_id'], $report_id]);
        header('Location: manage-reports.php?success=Report dismissed');
        exit();
    }
}

// Get reports with pagination
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$db = Database::getInstance();
$total_reports = $db->fetch("SELECT COUNT(*) as count FROM reports")['count'];
$total_pages = ceil($total_reports / $limit);

$reports = $db->fetchAll("
    SELECT r.*, u1.username as reporter_name, u2.username as reported_name,
           a.title as auction_title, a.id as auction_id
    FROM reports r 
    JOIN users u1 ON r.reporter_id = u1.id 
    LEFT JOIN users u2 ON r.reported_user_id = u2.id 
    LEFT JOIN auctions a ON r.auction_id = a.id 
    ORDER BY r.created_at DESC 
    LIMIT ? OFFSET ?
", [$limit, $offset]);

$page_title = 'Manage Reports';
require_once '../includes/header.php';
?>

<style>
.report-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    border-left: 4px solid #e2e8f0;
}

.report-card.pending {
    border-left-color: #f56565;
}

.report-card.resolved {
    border-left-color: #48bb78;
}

.report-card.dismissed {
    border-left-color: #718096;
}

.report-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.report-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 12px;
}

.report-type {
    font-size: 1.1rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 4px;
}

.report-meta {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    color: #4a5568;
}

.status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-pending { background: #fed7d7; color: #742a2a; }
.status-resolved { background: #c6f6d5; color: #22543d; }
.status-dismissed { background: #e2e8f0; color: #4a5568; }

.report-content {
    background: #f8f9fa;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 12px;
}

.report-description {
    margin-bottom: 8px;
    color: #2d3748;
}

.resolution {
    margin-top: 8px;
    padding-top: 8px;
    border-top: 1px solid #e2e8f0;
    color: #48bb78;
    font-style: italic;
}

.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn-sm {
    padding: 6px 12px;
    font-size: 0.8rem;
    border-radius: 6px;
}

.search-bar {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 30px;
    border-radius: 12px;
    width: 500px;
    max-width: 90%;
}

.stats-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.stats-number {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 4px;
}

.stats-label {
    color: #718096;
    font-size: 0.9rem;
}
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Manage Reports</h1>
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($_GET['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number text-danger"><?php echo $db->fetch("SELECT COUNT(*) as count FROM reports WHERE status = 'pending'")['count']; ?></div>
                        <div class="stats-label">Pending</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number text-success"><?php echo $db->fetch("SELECT COUNT(*) as count FROM reports WHERE status = 'resolved'")['count']; ?></div>
                        <div class="stats-label">Resolved</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number text-secondary"><?php echo $db->fetch("SELECT COUNT(*) as count FROM reports WHERE status = 'dismissed'")['count']; ?></div>
                        <div class="stats-label">Dismissed</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number text-primary"><?php echo $total_reports; ?></div>
                        <div class="stats-label">Total Reports</div>
                    </div>
                </div>
            </div>

            <!-- Search and Filters -->
            <div class="search-bar">
                <div class="row">
                    <div class="col-md-4">
                        <input type="text" class="form-control" placeholder="Search reports..." id="searchInput">
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="resolved">Resolved</option>
                            <option value="dismissed">Dismissed</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="typeFilter">
                            <option value="">All Types</option>
                            <option value="inappropriate_content">Inappropriate Content</option>
                            <option value="fraud">Fraud</option>
                            <option value="spam">Spam</option>
                            <option value="harassment">Harassment</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-outline-secondary w-100" onclick="refreshReports()">
                            <i class="fas fa-sync"></i> Refresh
                        </button>
                    </div>
                </div>
            </div>

            <!-- Reports List -->
            <div class="reports-container">
                <?php if (!empty($reports)): ?>
                    <?php foreach ($reports as $report): ?>
                        <div class="report-card <?php echo $report['status']; ?>" 
                             data-status="<?php echo $report['status']; ?>" 
                             data-type="<?php echo $report['report_type']; ?>">
                            <div class="report-header">
                                <div>
                                    <div class="report-type"><?php echo ucfirst(str_replace('_', ' ', $report['report_type'])); ?></div>
                                    <div class="text-muted">Report ID: #<?php echo $report['id']; ?></div>
                                </div>
                                <span class="status-badge status-<?php echo $report['status']; ?>">
                                    <?php echo ucfirst($report['status']); ?>
                                </span>
                            </div>
                            
                            <div class="report-meta">
                                <div class="meta-item">
                                    <i class="fas fa-user"></i>
                                    Reported by: <?php echo htmlspecialchars($report['reporter_name']); ?>
                                </div>
                                <?php if ($report['reported_name']): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-user-times"></i>
                                        Reported user: <?php echo htmlspecialchars($report['reported_name']); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($report['auction_title']): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-gavel"></i>
                                        Auction: <a href="../auction.php?id=<?php echo $report['auction_id']; ?>" target="_blank"><?php echo htmlspecialchars($report['auction_title']); ?></a>
                                    </div>
                                <?php endif; ?>
                                <div class="meta-item">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo time_ago($report['created_at']); ?>
                                </div>
                            </div>
                            
                            <div class="report-content">
                                <div class="report-description">
                                    <?php echo htmlspecialchars($report['description']); ?>
                                </div>
                                <?php if ($report['resolution']): ?>
                                    <div class="resolution">
                                        <strong>Resolution:</strong> <?php echo htmlspecialchars($report['resolution']); ?>
                                        <br><small>Resolved by admin <?php echo time_ago($report['resolved_at']); ?></small>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($report['status'] === 'pending'): ?>
                                <div class="action-buttons">
                                    <button class="btn btn-success btn-sm" onclick="showResolveModal(<?php echo $report['id']; ?>)">
                                        <i class="fas fa-check"></i> Resolve
                                    </button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to dismiss this report?');">
                                        <input type="hidden" name="action" value="dismiss_report">
                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm">
                                            <i class="fas fa-times"></i> Dismiss
                                        </button>
                                    </form>
                                    <button class="btn btn-info btn-sm" onclick="viewDetails(<?php echo $report['id']; ?>)">
                                        <i class="fas fa-eye"></i> Full Details
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="action-buttons">
                                    <button class="btn btn-info btn-sm" onclick="viewDetails(<?php echo $report['id']; ?>)">
                                        <i class="fas fa-eye"></i> View Details
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-flag fa-3x text-muted mb-3"></i>
                        <h4>No reports found</h4>
                        <p class="text-muted">There are no reports in the system yet.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Resolve Report Modal -->
<div id="resolveModal" class="modal">
    <div class="modal-content">
        <h4>Resolve Report</h4>
        <form method="POST">
            <input type="hidden" name="action" value="resolve_report">
            <input type="hidden" name="report_id" id="resolveReportId">
            
            <div class="mb-3">
                <label for="resolution" class="form-label">Resolution Details *</label>
                <textarea class="form-control" name="resolution" id="resolution" rows="4" required
                          placeholder="Describe how this report was resolved..."></textarea>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-success">Mark as Resolved</button>
                <button type="button" class="btn btn-secondary" onclick="hideResolveModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const reportCards = document.querySelectorAll('.report-card');
    
    reportCards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchTerm) ? 'block' : 'none';
    });
});

// Filter functionality
document.getElementById('statusFilter').addEventListener('change', filterReports);
document.getElementById('typeFilter').addEventListener('change', filterReports);

function filterReports() {
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const reportCards = document.querySelectorAll('.report-card');
    
    reportCards.forEach(card => {
        let show = true;
        
        if (statusFilter && card.dataset.status !== statusFilter) {
            show = false;
        }
        
        if (typeFilter && card.dataset.type !== typeFilter) {
            show = false;
        }
        
        card.style.display = show ? 'block' : 'none';
    });
}

function showResolveModal(reportId) {
    document.getElementById('resolveReportId').value = reportId;
    document.getElementById('resolveModal').style.display = 'block';
}

function hideResolveModal() {
    document.getElementById('resolveModal').style.display = 'none';
}

function viewDetails(reportId) {
    // This could show a detailed view with all information
    alert('Full report details view - Feature coming soon!');
}

function refreshReports() {
    location.reload();
}

// Close modal when clicking outside
document.getElementById('resolveModal').addEventListener('click', function(e) {
    if (e.target === this) {
        hideResolveModal();
    }
});

// Auto-refresh every 60 seconds for real-time updates
setInterval(refreshReports, 60000);
</script>

<?php require_once '../includes/footer.php'; ?>
