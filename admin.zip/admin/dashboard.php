<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin authentication check
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'super_admin'])) {
    header('Location: login.php');
    exit();
}

// Handle auction actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $auction_id = intval($_POST['auction_id'] ?? 0);
    
    if ($action === 'activate_auction' && $auction_id > 0) {
        $db = Database::getInstance();
        // Check if auction has end_time, if not set it to 7 days from now
        $auction = $db->fetch("SELECT end_time FROM auctions WHERE id = ? AND status = 'draft'", [$auction_id]);
        if ($auction) {
            if (empty($auction['end_time']) || $auction['end_time'] === '0000-00-00 00:00:00') {
                $end_time = date('Y-m-d H:i:s', strtotime('+7 days'));
                $db->query("UPDATE auctions SET status = 'active', end_time = ? WHERE id = ?", [$end_time, $auction_id]);
            } else {
                $db->query("UPDATE auctions SET status = 'active' WHERE id = ?", [$auction_id]);
            }
            header('Location: dashboard.php?success=Auction is now live!');
            exit();
        }
    }
}

// Get dashboard statistics
$db = Database::getInstance();
$stats = [
    'total_users' => $db->fetch("SELECT COUNT(*) as count FROM users")['count'],
    'total_auctions' => $db->fetch("SELECT COUNT(*) as count FROM auctions")['count'],
    'active_auctions' => $db->fetch("SELECT COUNT(*) as count FROM auctions WHERE status = 'active'")['count'],
    'total_bids' => $db->fetch("SELECT COUNT(*) as count FROM bids")['count'],
    'pending_reports' => $db->fetch("SELECT COUNT(*) as count FROM reports WHERE status = 'pending'")['count'] ?? 0
];

// Get recent activities
$recent_auctions = $db->fetchAll("
    SELECT a.id, a.title, a.status, a.created_at, u.username 
    FROM auctions a 
    JOIN users u ON a.seller_id = u.id 
    ORDER BY a.created_at DESC 
    LIMIT 5
");

$recent_users = $db->fetchAll("
    SELECT id, username, email, created_at, is_verified 
    FROM users 
    ORDER BY created_at DESC 
    LIMIT 5
");

$page_title = 'Admin Dashboard';
require_once '../includes/header.php';
?>

<style>
.dashboard-section {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 24px;
    overflow: hidden;
}

.section-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 20px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.section-title {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 12px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    text-align: center;
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.stat-card.users { border-left-color: #4299e1; }
.stat-card.auctions { border-left-color: #48bb78; }
.stat-card.active { border-left-color: #ed8936; }
.stat-card.bids { border-left-color: #9f7aea; }
.stat-card.reports { border-left-color: #f56565; }

.stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #2d3748;
    margin-bottom: 8px;
}

.stat-label {
    color: #718096;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.quick-action-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 12px;
    padding: 24px;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
    border: none;
    width: 100%;
}

.quick-action-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.quick-action-card i {
    font-size: 2rem;
    margin-bottom: 12px;
}

.quick-action-card h5 {
    margin: 0;
    font-weight: 600;
}

.activity-item {
    padding: 12px 16px;
    border-left: 3px solid #e2e8f0;
    margin-bottom: 8px;
    background: #f8f9fa;
    border-radius: 0 8px 8px 0;
    transition: all 0.3s ease;
}

.activity-item:hover {
    border-left-color: #667eea;
    background: #edf2f7;
}

.activity-title {
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 4px;
}

.activity-meta {
    font-size: 0.85rem;
    color: #718096;
}

.activity-actions {
    margin-top: 8px;
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.status-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
}

.status-active { background: #c6f6d5; color: #22543d; }
.status-draft { background: #fed7d7; color: #742a2a; }
.status-ended { background: #e2e8f0; color: #4a5568; }
.status-verified { background: #c6f6d5; color: #22543d; }
.status-pending { background: #feebc8; color: #7c2d12; }
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Admin Dashboard</h1>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" onclick="location.reload()">
                        <i class="fas fa-sync"></i> Refresh
                    </button>
                    <button class="btn btn-primary" onclick="window.open('../index.php', '_blank')">
                        <i class="fas fa-external-link-alt"></i> View Site
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="stat-card users">
                <div class="stat-number"><?php echo number_format($stats['total_users']); ?></div>
                <div class="stat-label">Total Users</div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="stat-card auctions">
                <div class="stat-number"><?php echo number_format($stats['total_auctions']); ?></div>
                <div class="stat-label">Total Auctions</div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="stat-card active">
                <div class="stat-number"><?php echo number_format($stats['active_auctions']); ?></div>
                <div class="stat-label">Active Auctions</div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="stat-card bids">
                <div class="stat-number"><?php echo number_format($stats['total_bids']); ?></div>
                <div class="stat-label">Total Bids</div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="stat-card reports">
                <div class="stat-number"><?php echo number_format($stats['pending_reports']); ?></div>
                <div class="stat-label">Pending Reports</div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-bolt"></i>
                        Quick Actions
                    </h2>
                </div>
                <div class="p-4">
                    <div class="row">
                        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                            <button class="quick-action-card" onclick="window.location.href='create-auction.php'">
                                <i class="fas fa-plus"></i>
                                <h5>Create Auction</h5>
                            </button>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                            <button class="quick-action-card" onclick="window.location.href='manage-users.php'">
                                <i class="fas fa-users"></i>
                                <h5>Manage Users</h5>
                            </button>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                            <button class="quick-action-card" onclick="window.location.href='manage-auctions.php'">
                                <i class="fas fa-gavel"></i>
                                <h5>All Auctions</h5>
                            </button>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                            <button class="quick-action-card" onclick="window.location.href='manage-categories.php'">
                                <i class="fas fa-tags"></i>
                                <h5>Categories</h5>
                            </button>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                            <button class="quick-action-card" onclick="window.location.href='manage-reports.php'">
                                <i class="fas fa-flag"></i>
                                <h5>Reports</h5>
                            </button>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                            <button class="quick-action-card" onclick="window.location.href='system-settings.php'">
                                <i class="fas fa-cog"></i>
                                <h5>Settings</h5>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-clock"></i>
                        Recent Auctions
                    </h2>
                    <button class="btn btn-light btn-sm" onclick="window.location.href='manage-auctions.php'">
                        View All
                    </button>
                </div>
                <div class="section-body">
                    <?php if (!empty($recent_auctions)): ?>
                        <?php foreach ($recent_auctions as $auction): ?>
                            <div class="activity-item">
                                <div class="activity-title"><?php echo htmlspecialchars($auction['title']); ?></div>
                                <div class="activity-meta">
                                    by <?php echo htmlspecialchars($auction['username']); ?> • 
                                    <?php echo time_ago($auction['created_at']); ?>
                                    <span class="status-badge status-<?php echo $auction['status']; ?> ms-2">
                                        <?php echo ucfirst($auction['status']); ?>
                                    </span>
                                </div>
                                <div class="activity-actions">
                                    <?php if ($auction['status'] === 'draft'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="activate_auction">
                                            <input type="hidden" name="auction_id" value="<?php echo $auction['id']; ?>">
                                            <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Go live with this auction?');">
                                                <i class="fas fa-play"></i> Go Live
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <button class="btn btn-info btn-sm" onclick="window.location.href='manage-auctions.php'">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    <button class="btn btn-warning btn-sm" onclick="window.location.href='edit-auction.php?id=<?php echo $auction['id']; ?>'">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-gavel fa-2x mb-2"></i>
                            <p>No recent auctions</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-user-plus"></i>
                        New Users
                    </h2>
                    <button class="btn btn-light btn-sm" onclick="window.location.href='manage-users.php'">
                        View All
                    </button>
                </div>
                <div class="section-body">
                    <?php if (!empty($recent_users)): ?>
                        <?php foreach ($recent_users as $user): ?>
                            <div class="activity-item">
                                <div class="activity-title"><?php echo htmlspecialchars($user['username']); ?></div>
                                <div class="activity-meta">
                                    <?php echo htmlspecialchars($user['email']); ?> • 
                                    <?php echo time_ago($user['created_at']); ?>
                                    <span class="status-badge status-<?php echo $user['is_verified'] ? 'verified' : 'pending'; ?> ms-2">
                                        <?php echo $user['is_verified'] ? 'Verified' : 'Pending'; ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-users fa-2x mb-2"></i>
                            <p>No recent users</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Real-time synchronization
let lastUpdate = Date.now();

function checkForUpdates() {
    fetch('real-time-sync.php?action=get_stats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateDashboardStats(data.stats);
            }
        })
        .catch(error => console.log('Stats update error:', error));
    
    fetch('real-time-sync.php?action=get_recent_auctions')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateRecentAuctions(data.auctions);
            }
        })
        .catch(error => console.log('Auctions update error:', error));
}

function updateDashboardStats(newStats) {
    const statElements = {
        'total_users': document.querySelector('.users .stat-number'),
        'total_auctions': document.querySelector('.auctions .stat-number'),
        'active_auctions': document.querySelector('.active .stat-number'),
        'total_bids': document.querySelector('.bids .stat-number')
    };
    
    Object.keys(statElements).forEach(key => {
        const element = statElements[key];
        if (element && newStats[key] !== undefined) {
            const oldValue = parseInt(element.textContent.replace(/,/g, ''));
            const newValue = newStats[key];
            
            if (oldValue !== newValue) {
                element.style.transform = 'scale(1.2)';
                element.style.color = '#48bb78';
                element.textContent = newValue.toLocaleString();
                
                setTimeout(() => {
                    element.style.transform = 'scale(1)';
                    element.style.color = '';
                }, 500);
            }
        }
    });
}

function updateRecentAuctions(auctions) {
    const container = document.querySelector('.dashboard-section:nth-child(3) .section-body');
    if (!container) return;
    
    let html = '';
    auctions.forEach(auction => {
        html += `
            <div class="activity-item" style="opacity: 0; animation: fadeIn 0.5s forwards;">
                <div class="activity-title">${auction.title}</div>
                <div class="activity-meta">
                    by ${auction.username} • 
                    ${timeAgo(auction.created_at)}
                    <span class="status-badge status-${auction.status} ms-2">
                        ${auction.status}
                    </span>
                </div>
                <div class="activity-actions">
                    ${auction.status === 'draft' ? `
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="activate_auction">
                            <input type="hidden" name="auction_id" value="${auction.id}">
                            <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Go live with this auction?');">
                                <i class="fas fa-play"></i> Go Live
                            </button>
                        </form>
                    ` : ''}
                    <button class="btn btn-info btn-sm" onclick="window.location.href='manage-auctions.php'">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            </div>
        `;
    });
    
    if (html) {
        container.innerHTML = html;
    }
}

function timeAgo(datetime) {
    const time = new Date(datetime).getTime();
    const now = Date.now();
    const diff = Math.floor((now - time) / 1000);
    
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff / 60) + ' minutes ago';
    if (diff < 86400) return Math.floor(diff / 3600) + ' hours ago';
    return Math.floor(diff / 86400) + ' days ago';
}

// Check for updates every 5 seconds
setInterval(checkForUpdates, 5000);

// Check when page becomes visible again
document.addEventListener('visibilitychange', function() {
    if (!document.hidden) {
        checkForUpdates();
    }
});

// Add fade-in animation
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
`;
document.head.appendChild(style);
</script>

<?php require_once '../includes/footer.php'; ?>
