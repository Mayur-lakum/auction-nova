<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin authentication check
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'super_admin'])) {
    header('Location: login.php');
    exit();
}

// Handle auction actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $auction_id = intval($_POST['auction_id'] ?? 0);
    
    if ($action === 'toggle_status' && $auction_id > 0) {
        $db = Database::getInstance();
        $auction = $db->fetch("SELECT status FROM auctions WHERE id = ?", [$auction_id]);
        if ($auction) {
            $new_status = $auction['status'] === 'active' ? 'paused' : 'active';
            $db->query("UPDATE auctions SET status = ? WHERE id = ?", [$new_status, $auction_id]);
            header('Location: manage-auctions.php?success=Auction status updated');
            exit();
        }
    } elseif ($action === 'delete_auction' && $auction_id > 0) {
        $db = Database::getInstance();
        $db->query("DELETE FROM auctions WHERE id = ?", [$auction_id]);
        header('Location: manage-auctions.php?success=Auction deleted');
        exit();
    } elseif ($action === 'extend_auction' && $auction_id > 0) {
        $days = intval($_POST['extend_days'] ?? 1);
        $db = Database::getInstance();
        $db->query("UPDATE auctions SET end_time = DATE_ADD(end_time, INTERVAL ? DAY) WHERE id = ?", [$days, $auction_id]);
        header('Location: manage-auctions.php?success=Auction extended');
        exit();
    }
}

// Get auctions with pagination
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$db = Database::getInstance();
$total_auctions = $db->fetch("SELECT COUNT(*) as count FROM auctions")['count'];
$total_pages = ceil($total_auctions / $limit);

$auctions = $db->fetchAll("
    SELECT a.*, u.username, c.name as category_name,
           (SELECT COUNT(*) FROM bids WHERE auction_id = a.id) as bid_count,
           (SELECT MAX(amount) FROM bids WHERE auction_id = a.id) as highest_bid
    FROM auctions a 
    JOIN users u ON a.seller_id = u.id 
    LEFT JOIN categories c ON a.category_id = c.id 
    ORDER BY a.created_at DESC 
    LIMIT ? OFFSET ?
", [$limit, $offset]);

$page_title = 'Manage Auctions';
require_once '../includes/header.php';
?>

<style>
.auction-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.auction-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.auction-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 12px;
}

.auction-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 4px;
}

.auction-meta {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    color: #4a5568;
}

.status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-active { background: #c6f6d5; color: #22543d; }
.status-paused { background: #feebc8; color: #7c2d12; }
.status-draft { background: #e2e8f0; color: #4a5568; }
.status-ended { background: #fed7d7; color: #742a2a; }

.price-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    padding: 12px;
    background: #f8f9fa;
    border-radius: 8px;
}

.current-price {
    font-size: 1.5rem;
    font-weight: 700;
    color: #48bb78;
}

.bid-count {
    font-size: 0.9rem;
    color: #718096;
}

.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn-sm {
    padding: 6px 12px;
    font-size: 0.8rem;
    border-radius: 6px;
}

.search-bar {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.extend-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.extend-modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 30px;
    border-radius: 12px;
    width: 400px;
    max-width: 90%;
}
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Manage Auctions</h1>
                <div class="d-flex gap-2">
                    <a href="create-auction.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Create Auction
                    </a>
                    <a href="dashboard.php" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($_GET['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Search and Filters -->
            <div class="search-bar">
                <div class="row">
                    <div class="col-md-4">
                        <input type="text" class="form-control" placeholder="Search auctions..." id="searchInput">
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="paused">Paused</option>
                            <option value="draft">Draft</option>
                            <option value="ended">Ended</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="categoryFilter">
                            <option value="">All Categories</option>
                            <?php 
                            $categories = $db->fetchAll("SELECT id, name FROM categories ORDER BY name");
                            foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-outline-secondary w-100" onclick="refreshAuctions()">
                            <i class="fas fa-sync"></i> Refresh
                        </button>
                    </div>
                </div>
            </div>

            <!-- Auctions List -->
            <div class="auctions-container">
                <?php if (!empty($auctions)): ?>
                    <?php foreach ($auctions as $auction): ?>
                        <div class="auction-card" data-status="<?php echo $auction['status']; ?>" data-category="<?php echo $auction['category_id']; ?>">
                            <div class="auction-header">
                                <div>
                                    <div class="auction-title"><?php echo htmlspecialchars($auction['title']); ?></div>
                                    <div class="text-muted">by <?php echo htmlspecialchars($auction['username']); ?></div>
                                </div>
                                <span class="status-badge status-<?php echo $auction['status']; ?>">
                                    <?php echo ucfirst($auction['status']); ?>
                                </span>
                            </div>
                            
                            <div class="auction-meta">
                                <div class="meta-item">
                                    <i class="fas fa-tag"></i>
                                    <?php echo htmlspecialchars($auction['category_name'] ?? 'Uncategorized'); ?>
                                </div>
                                <div class="meta-item">
                                    <i class="fas fa-calendar"></i>
                                    Created <?php echo time_ago($auction['created_at']); ?>
                                </div>
                                <div class="meta-item">
                                    <i class="fas fa-clock"></i>
                                    <?php echo time_remaining($auction['end_time']); ?>
                                </div>
                            </div>
                            
                            <div class="price-info">
                                <div>
                                    <div class="current-price">$<?php echo number_format($auction['current_price'], 2); ?></div>
                                    <div class="text-muted">Current Price</div>
                                </div>
                                <div class="text-end">
                                    <div class="bid-count"><?php echo $auction['bid_count']; ?> bids</div>
                                    <div class="text-muted">Highest: $<?php echo number_format($auction['highest_bid'] ?: 0, 2); ?></div>
                                </div>
                            </div>
                            
                            <div class="action-buttons">
                                <button class="btn btn-info btn-sm" onclick="viewAuction(<?php echo $auction['id']; ?>)">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="btn btn-warning btn-sm" onclick="editAuction(<?php echo $auction['id']; ?>)">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="auction_id" value="<?php echo $auction['id']; ?>">
                                    <button type="submit" class="btn btn-<?php echo $auction['status'] === 'active' ? 'warning' : 'success'; ?> btn-sm">
                                        <i class="fas fa-<?php echo $auction['status'] === 'active' ? 'pause' : 'play'; ?>"></i>
                                        <?php echo $auction['status'] === 'active' ? 'Pause' : 'Activate'; ?>
                                    </button>
                                </form>
                                
                                <button class="btn btn-secondary btn-sm" onclick="showExtendModal(<?php echo $auction['id']; ?>)">
                                    <i class="fas fa-clock"></i> Extend
                                </button>
                                
                                <form method="POST" style="display: inline;" onsubmitlalal="return confirm('Are you sure you want to delete this auction?');">
                                    <input type="hidden" name="action" value="delete_auction">
                                    <input type="hidden" name="auction_id" value="<?php echo $auction['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-gavel fa-3x text-muted mb-3"></i>
                        <h4>No auctions found</h4>
                        <p class="text-muted">There are no auctions in the system yet.</p>
                        <a href="create-auction.php" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Create First Auction
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav class="mt-ebb">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            comprehended
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Extend Auction Modal -->
<div id="extendModal" class="extend-modal">
    <div class="extend-modal-content">
        <h4>Extend Auction</h4>
        <form method="POST" id="extendForm">
            <input type="hidden" name="action" value="extend_auction">
            <input type="hidden" name="auction_id" id="extendAuctionId">
            
            <div class="mb-3">
                <label for="extend_days" class="form-label">Extend by days:</label>
                <select class="form-select" name="extend_days" id="extend_days">
                    <option value="1">1 day</option>
                    <option value="3">3 days</option>
                    <option value="7">1 week</option>
                    <option value="14">2 weeks</option>
                    <option value="30">1 month</option>
                </select>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Extend</button>
                <button type="button" class="btn btn-secondary" onclick="hideExtendModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const auctionCards = document.querySelectorAll('.auction-card');
    
    auctionCards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchTerm) ? 'block' : 'none';
    });
});

// Filter functionality
document.getElementById('statusFilter').addEventListener('change', filterAuctions);
document.getElementById('categoryFilter').addEventListener('change', filterAuctions);

function filterAuctions() {
    const statusFilter = document.getElementById('statusFilter').value;
    const categoryFilter = document.getElementById('categoryFilter').value;
    const auctionCards = document.querySelectorAll('.auction-card');
    
    auctionCards.forEach(card => {
        let show = true;
        
        if (statusFilter && card.dataset.status !== statusFilter) {
            show = false;
        }
        
        if (categoryFilter && card.dataset.category !== categoryFilter) {
            show = false;
        }
        
        card.style.display = show ? 'block' : 'none';
    });
}

function showExtendModal(auctionId) {
    document.getElementById('extendAuctionId').value = auctionId;
    document.getElementById('extendModal').style.display = 'block';
}

function hideExtendModal() {
    document.getElementById('extendModal').style.display = 'none';
}

function viewAuction(auctionId) {
    window.open('../auction.php?id=' + auctionId, '_blank');
}

function editAuction(auctionId) {
    window.location.href = 'edit-auction.php?id=' + auctionId;
}

function refreshAuctions() {
    location.reload();
}

// Close modal when clicking outside
document.getElementById('extendModal').addEventListener('click', function(e) {
    if (e.target === this) {
        hideExtendModal();
    }
});

// Auto-refresh every 30 seconds for real-time updates
setInterval(refreshAuctions, 30000);
</script>

<?php require_once '../includes/footer.php'; ?>
