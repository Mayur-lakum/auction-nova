<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Simple admin check - bypass for now
if (!isset($_SESSION['user_id'])) {
    header('Location: direct-login.php');
    exit();
}

$message = '';
$error = '';

// Handle auction creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize_input($_POST['title'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    $category_id = intval($_POST['category_id'] ?? 0);
    $starting_price = floatval($_POST['starting_price'] ?? 0);
    $reserve_price = floatval($_POST['reserve_price'] ?? 0);
    $end_time = $_POST['end_time'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = 'Invalid request.';
    } elseif (empty($title) || empty($description) || $category_id <= 0 || $starting_price <= 0 || empty($end_time)) {
        $error = 'Please fill all required fields.';
    } else {
        try {
            $db = Database::getInstance();
            
            $db->query(
                "INSERT INTO auctions (title, description, category_id, seller_id, starting_price, reserve_price, current_price, end_time, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', NOW())",
                [$title, $description, $category_id, $_SESSION['user_id'], $starting_price, $reserve_price, $starting_price, $end_time]
            );
            
            $message = "Auction created successfully!";
            
        } catch (Exception $e) {
            $error = 'Failed to create auction: ' . $e->getMessage();
        }
    }
}

// Get categories
$db = Database::getInstance();
$categories = $db->fetchAll("SELECT id, name FROM categories ORDER BY name");

$page_title = 'Create Auction';
require_once '../includes/header.php';
?>

<style>
.form-control, .form-select {
    border-radius: 8px;
    border: 2px solid #e2e8f0;
    padding: 12px 16px;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.btn-lg {
    padding: 12px 24px;
    font-size: 1.1rem;
    font-weight: 600;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.btn-secondary {
    background: #6c757d;
    border: none;
    color: white;
}

.btn-secondary:hover {
    background: #5a6268;
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(108, 117, 125, 0.3);
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 12px 12px 0 0 !important;
}

.card {
    border-radius: 12px;
    border: none;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.form-label {
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 8px;
}

.alert {
    border-radius: 8px;
    border: none;
    padding: 16px 20px;
}
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border-0 shadow-lg">
                <div class="card-header text-white">
                    <h4 class="mb-0">
                        <i class="fas fa-gavel me-2"></i>
                        Create New Auction
                    </h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($message): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" id="createAuctionForm">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <div class="row">
                            <div class="col-md-8 mb-4">
                                <label for="title" class="form-label">Auction Title *</label>
                                <input type="text" class="form-control" id="title" name="title" 
                                       value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" 
                                       placeholder="Enter auction title" required>
                            </div>
                            <div class="col-md-4 mb-4">
                                <label for="category_id" class="form-label">Category *</label>
                                <select class="form-select" id="category_id" name="category_id" required>
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" 
                                                <?php echo (($_POST['category_id'] ?? '') == $category['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="description" class="form-label">Description *</label>
                            <textarea class="form-control" id="description" name="description" rows="4" 
                                      placeholder="Describe the item being auctioned" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <label for="starting_price" class="form-label">Starting Price ($) *</label>
                                <input type="number" class="form-control" id="starting_price" name="starting_price" 
                                       value="<?php echo htmlspecialchars($_POST['starting_price'] ?? ''); ?>" 
                                       placeholder="0.00" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-4 mb-4">
                                <label for="reserve_price" class="form-label">Reserve Price ($)</label>
                                <input type="number" class="form-control" id="reserve_price" name="reserve_price" 
                                       value="<?php echo htmlspecialchars($_POST['reserve_price'] ?? ''); ?>" 
                                       placeholder="0.00" step="0.01" min="0">
                                <div class="form-text text-muted">Minimum price to accept (optional)</div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <label for="end_time" class="form-label">Auction End Time *</label>
                                <input type="datetime-local" class="form-control" id="end_time" name="end_time" 
                                       value="<?php echo htmlspecialchars($_POST['end_time'] ?? ''); ?>" required>
                                <div class="form-text text-muted">When the auction will end</div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-5">
                            <a href="dashboard.php" class="btn考察 btn-secondary btn-lg">
                                <i class="fas fa-arrow-left me-2"></i>
                                Back to Dashboard
                            </a>
                            <button type="submit" class="btn btn-primary btn-lg" id="submitBtn">
                                <i class="fas fa-plus me-2"></i>
                                Create Auction
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Set minimum datetime to current time
document.getElementById('end_time').min = new Date().toISOString().slice(0, 16);

// Form submission with loading state
document.getElementById('createAuctionForm').addEventListener('submit', function(e) {
    const submitBtn = document.getElementById('submitBtn');
    const originalText = submitBtn.innerHTML;
    
    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Creating...';
    submitBtn.disabled = true;
    
    // If form validation fails, reset button
    setTimeout(() => {
        if (submitBtn.disabled) {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }, 3000);
});
</script>

<?php require_once '../includes/footer.php'; ?>
