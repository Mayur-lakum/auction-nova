<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin authentication check
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'super_admin'])) {
    header('Location: login.php');
    exit();
}

// Handle settings updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_general') {
        $site_name = sanitize_input($_POST['site_name'] ?? '');
        $site_email = sanitize_input($_POST['site_email'] ?? '');
        $maintenance_mode = isset($_POST['maintenance_mode']) ? 1 : 0;
        
        $db = Database::getInstance();
        $db->query("UPDATE settings SET value = ? WHERE name = 'site_name'", [$site_name]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'site_email'", [$site_email]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'maintenance_mode'", [$maintenance_mode]);
        
        header('Location: system-settings.php?success=General settings updated');
        exit();
    } elseif ($action === 'update_auction') {
        $min_bid_increment = floatval($_POST['min_bid_increment'] ?? 1);
        $max_auction_duration = intval($_POST['max_auction_duration'] ?? 30);
        $listing_fee = floatval($_POST['listing_fee'] ?? 0);
        $commission_rate = floatval($_POST['commission_rate'] ?? 5);
        
        $db = Database::getInstance();
        $db->query("UPDATE settings SET value = ? WHERE name = 'min_bid_increment'", [$min_bid_increment]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'max_auction_duration'", [$max_auction_duration]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'listing_fee'", [$listing_fee]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'commission_rate'", [$commission_rate]);
        
        header('Location: system-settings.php?success=Auction settings updated');
        exit();
    } elseif ($action === 'update_email') {
        $smtp_host = sanitize_input($_POST['smtp_host'] ?? '');
        $smtp_port = intval($_POST['smtp_port'] ?? 587);
        $smtp_username = sanitize_input($_POST['smtp_username'] ?? '');
        $smtp_password = sanitize_input($_POST['smtp_password'] ?? '');
        $email_from = sanitize_input($_POST['email_from'] ?? '');
        
        $db = Database::getInstance();
        $db->query("UPDATE settings SET value = ? WHERE name = 'smtp_host'", [$smtp_host]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'smtp_port'", [$smtp_port]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'smtp_username'", [$smtp_username]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'smtp_password'", [$smtp_password]);
        $db->query("UPDATE settings SET value = ? WHERE name = 'email_from'", [$email_from]);
        
        header('Location: system-settings.php?success=Email settings updated');
        exit();
    }
}

// Get current settings
$db = Database::getInstance();
$settings = [];
$setting_rows = $db->fetchAll("SELECT name, value FROM settings");
foreach ($setting_rows as $row) {
    $settings[$row['name']] = $row['value'];
}

$page_title = 'System Settings';
require_once '../includes/header.php';
?>

<style>
.settings-section {
    background: white;
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.section-header {
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 12px;
    margin-bottom: 20px;
}

.section-title {
    font-size: 1.3rem;
    font-weight: 600;
    color: #2d3748;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.form-label {
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 6px;
}

.form-control, .form-select {
    border-radius: 8px;
    border: 2px solid #e2e8f0;
    padding: 10px 12px;
    transition: all 0.3s ease;
}

.form-control:focus, .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-text {
    color: #718096;
    font-size: 0.85rem;
    margin-top: 4px;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
    border-radius: 34px;
}

.slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
}

input:checked + .slider {
    background-color: #48bb78;
}

input:checked + .slider:before {
    transform: translateX(26px);
}

.setting-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

.setting-info {
    flex: 1;
}

.setting-control {
    flex: 1;
    max-width: 300px;
}

.alert-success {
    border-radius: 8px;
    border: none;
    padding: 12px 16px;
}
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>System Settings</h1>
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($_GET['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- General Settings -->
            <div class="settings-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-cog"></i>
                        General Settings
                    </h2>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="update_general">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="site_name" class="form-label">Site Name</label>
                                <input type="text" class="form-control" name="site_name" id="site_name" 
                                       value="<?php echo htmlspecialchars($settings['site_name'] ?? 'Auction Nova'); ?>">
                                <div class="form-text">Name of your auction website</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="site_email" class="form-label">Site Email</label>
                                <input type="email" class="form-control" name="site_email" id="site_email" 
                                       value="<?php echo htmlspecialchars($settings['site_email'] ?? 'admin@auctionnova.com'); ?>">
                                <div class="form-text">Contact email for the website</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="setting-row">
                        <div class="setting-info">
                            <label class="form-label">Maintenance Mode</label>
                            <div class="form-text">Put the site in maintenance mode (users cannot access)</div>
                        </div>
                        <div class="setting-control">
                            <label class="switch">
                                <input type="checkbox" name="maintenance_mode" 
                                       <?php echo ($settings['maintenance_mode'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save General Settings
                        </button>
                    </div>
                </form>
            </div>

            <!-- Auction Settings -->
            <div class="settings-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-gavel"></i>
                        Auction Settings
                    </h2>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="update_auction">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="min_bid_increment" class="form-label">Minimum Bid Increment ($)</label>
                                <input type="number" class="form-control" name="min_bid_increment" id="min_bid_increment" 
                                       value="<?php echo htmlspecialchars($settings['min_bid_increment'] ?? 1); ?>" 
                                       step="0.01" min="0.01">
                                <div class="form-text">Minimum amount users can increase a bid by</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="max_auction_duration" class="form-label">Max Auction Duration (days)</label>
                                <input type="number" class="form-control" name="max_auction_duration" id="max_auction_duration" 
                                       value="<?php echo htmlspecialchars($settings['max_auction_duration'] ?? 30); ?>" 
                                       min="1" max="365">
                                <div class="form-text">Maximum length of an auction in days</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="listing_fee" class="form-label">Listing Fee ($)</label>
                                <input type="number" class="form-control" name="listing_fee" id="listing_fee" 
                                       value="<?php echo htmlspecialchars($settings['listing_fee'] ?? 0); ?>" 
                                       step="0.01" min="0">
                                <div class="form-text">Fee charged to create an auction</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="commission_rate" class="form-label">Commission Rate (%)</label>
                                <input type="number" class="form-control" name="commission_rate" id="commission_rate" 
                                       value="<?php echo htmlspecialchars($settings['commission_rate'] ?? 5); ?>" 
                                       step="0.1" min="0" max="100">
                                <div class="form-text">Percentage charged on final sale price</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Auction Settings
                        </button>
                    </div>
                </form>
            </div>

            <!-- Email Settings -->
            <div class="settings-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-envelope"></i>
                        Email Settings
                    </h2>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="update_email">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="smtp_host" class="form-label">SMTP Host</label>
                                <input type="text" class="form-control" name="smtp_host" id="smtp_host" 
                                       value="<?php echo htmlspecialchars($settings['smtp_host'] ?? ''); ?>">
                                <div class="form-text">SMTP server hostname</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="smtp_port" class="form-label">SMTP Port</label>
                                <input type="number" class="form-control" name="smtp_port" id="smtp_port" 
                                       value="<?php echo htmlspecialchars($settings['smtp_port'] ?? 587); ?>">
                                <div class="form-text">SMTP server port (usually 587, 465, or 25)</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="smtp_username" class="form-label">SMTP Username</label>
                                <input type="text" class="form-control" name="smtp_username" id="smtp_username" 
                                       value="<?php echo htmlspecialchars($settings['smtp_username'] ?? ''); ?>">
                                <div class="form-text">SMTP authentication username</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="smtp_password" class="form-label">SMTP Password</label>
                                <input type="password" class="form-control" name="smtp_password" id="smtp_password" 
                                       value="<?php echo htmlspecialchars($settings['smtp_password'] ?? ''); ?>">
                                <div class="form-text">SMTP authentication password</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email_from" class="form-label">From Email Address</label>
                        <input type="email" class="form-control" name="email_from" id="email_from" 
                               value="<?php echo htmlspecialchars($settings['email_from'] ?? 'noreply@auctionnova.com'); ?>">
                        <div class="form-text">Email address that system emails come from</div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Email Settings
                        </button>
                        <button type="button" class="btn btn-info ms-2" onclick="testEmail()">
                            <i class="fas fa-paper-plane"></i> Test Email
                        </button>
                    </div>
                </form>
            </div>

            <!-- System Information -->
            <div class="settings-section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-info-circle"></i>
                        System Information
                    </h2>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <h5>Server Information</h5>
                        <table class="table table-sm">
                            <tr>
                                <td>PHP Version:</td>
                                <td><?php echo PHP_VERSION; ?></td>
                            </tr>
                            <tr>
                                <td>Server Software:</td>
                                <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></td>
                            </tr>
                            <tr>
                                <td>Database:</td>
                                <td>MySQL</td>
                            </tr>
                            <tr>
                                <td>Timezone:</td>
                                <td><?php echo date_default_timezone_get(); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h5>System Statistics</h5>
                        <table class="table table-sm">
                            <tr>
                                <td>Total Users:</td>
                                <td><?php echo number_format($db->fetch("SELECT COUNT(*) as count FROM users")['count']); ?></td>
                            </tr>
                            <tr>
                                <td>Total Auctions:</td>
                                <td><?php echo number_format($db->fetch("SELECT COUNT(*) as count FROM auctions")['count']); ?></td>
                            </tr>
                            <tr>
                                <td>Total Bids:</td>
                                <td><?php echo number_format($db->fetch("SELECT COUNT(*) as count FROM bids")['count']); ?></td>
                            </tr>
                            <tr>
                                <td>Database Size:</td>
                                <td><?php echo round(db_size() / 1024 / 1024, 2); ?> MB</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function testEmail() {
    alert('Email test functionality - This would send a test email to verify SMTP settings are working correctly.');
}

// Auto-save functionality (optional enhancement)
let autoSaveTimer;
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('input', function() {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(() => {
            // Could implement auto-save here
            console.log('Auto-save triggered');
        }, 30000); // Auto-save after 30 seconds of inactivity
    });
});
</script>

<?php 
// Helper function to get database size
function db_size() {
    $db = Database::getInstance();
    $result = $db->fetch("SELECT SUM(data_length + index_length) as size FROM information_schema.tables WHERE table_schema = DATABASE()");
    return $result['size'] ?? 0;
}

require_once '../includes/footer.php'; ?>
