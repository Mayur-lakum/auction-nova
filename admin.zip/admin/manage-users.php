<?php
session_start();
require_once '../config/config.php';
require_once '../includes/Database.php';
require_once '../includes/auth.php';

// Admin authentication check
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'super_admin'])) {
    header('Location: login.php');
    exit();
}

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $user_id = intval($_POST['user_id'] ?? 0);
    
    if ($action === 'toggle_status' && $user_id > 0) {
        $db = Database::getInstance();
        $user = $db->fetch("SELECT is_active FROM users WHERE id = ?", [$user_id]);
        if ($user) {
            $new_status = $user['is_active'] ? 0 : 1;
            $db->execute("UPDATE users SET is_active = ? WHERE id = ?", [$new_status, $user_id]);
            header('Location: manage-users.php?success=User status updated');
            exit();
        }
    } elseif ($action === 'toggle_verification' && $user_id > 0) {
        $db = Database::getInstance();
        $user = $db->fetch("SELECT is_verified FROM users WHERE id = ?", [$user_id]);
        if ($user) {
            $new_status = $user['is_verified'] ? 0 : 1;
            $db->execute("UPDATE users SET is_verified = ? WHERE id = ?", [$new_status, $user_id]);
            header('Location: manage-users.php?success=User verification updated');
            exit();
        }
    } elseif ($action === 'delete_user' && $user_id > 0) {
        $db = Database::getInstance();
        $db->execute("DELETE FROM users WHERE id = ?", [$user_id]);
        header('Location: manage-users.php?success=User deleted');
        exit();
    }
}

// Get users with pagination
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$db = Database::getInstance();
$total_users = $db->fetch("SELECT COUNT(*) as count FROM users")['count'];
$total_pages = ceil($total_users / $limit);

$users = $db->fetchAll("
    SELECT id, username, email, first_name, last_name, role, is_active, is_verified, created_at
    FROM users 
    ORDER BY created_at DESC 
    LIMIT ? OFFSET ?
", [$limit, $offset]);

$page_title = 'Manage Users';
require_once '../includes/header.php';
?>

<style>
.user-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.user-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.user-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 12px;
}

.user-info h5 {
    margin: 0;
    color: #2d3748;
    font-weight: 600;
}

.user-info p {
    margin: 4px 0;
    color: #718096;
    font-size: 0.9rem;
}

.user-meta {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    color: #4a5568;
}

.status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-active { background: #c6f6d5; color: #22543d; }
.status-inactive { background: #fed7d7; color: #742a2a; }
.status-verified { background: #c6f6d5; color: #22543d; }
.status-pending { background: #feebc8; color: #7c2d12; }
.role-admin { background: #bee3f8; color: #2c5282; }
.role-user { background: #e2e8f0; color: #4a5568; }

.action  . .btn-sm {
   ikan
    padding: 6px 12px;
    font-size: 0.8rem;
    border-radius: 6px;
}

.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.search-bar {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Manage Users</h1>
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($_GET['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Search Bar -->
            <div class="search-bar">
                <div class="row">
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="Search users..." id="searchInput">
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="roleFilter">
                            <option value="">All Roles</option>
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                            <option value="super_admin">Super Admin</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Users List -->
            <div class="users-container">
                <?php if (!empty($users)): ?>
                    <?php foreach ($users as $user): ?>
                        <div class="user-card">
                            <div class="user-header">
                                <div class="user-info">
                                    <h5><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h5>
                                    <p>@<?php echo htmlspecialchars($user['username']); ?></p>
                                    <p><?php echo htmlspecialchars($user['email']); ?></p>
                                </div>
                                <div class="user-actions">
                                    <span class="status-badge role-<?php echo $user['role']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $user['role'])); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="user-meta">
                                <div class="meta-item">
                                    <i class="fas fa-calendar"></i>
                                    Joined <?php echo date('M j, Y', strtotime($user['created_at'])); ?>
                                </div>
                                <div class="meta-item">
                                    <span class="status-badge status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                        <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </div>
                                <div class="meta-item">
                                    <span class="status-badge status-<?php echo $user['is_verified'] ? 'verified' : 'pending'; ?>">
                                        <?php echo $user['is_verified'] ? 'Verified' : 'Pending'; ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="action-buttons">
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="btn btn-<?php echo $user['is_active'] ? 'warning' : 'success'; ?> btn-sm">
                                        <i class="fas fa-<?php echo $user['is_active'] ? 'pause' : 'play'; ?>"></i>
                                        <?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                    </button>
                                </form>
                                
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="toggle_verification">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="btn btn-<?php echo $user['is_verified'] ? 'secondary' : 'primary'; ?> btn-sm">
                                        <i class="fas fa-<?php echo $user['is_verified'] ? 'times' : 'check'; ?>"></i>
                                        <?php echo $user['is_verified'] ? 'Unverify' : 'Verify'; ?>
                                    </button>
                                </form>
                                
                                <button class="btn btn-info btn-sm" onclick="viewUserDetails(<?php echo $user['id']; ?>)">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                
                                <?php if ($user['role'] !== 'super_admin' && $user['id'] != $_SESSION['user_id']): ?>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-users fa-3x text-muted mb-3"></i>
                        <h4>No users found</h4>
                        <p class="text-muted">There are no users in the system yet.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const userCards = document.querySelectorAll('.user-card');
    
    userCards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchTerm) ? 'block' : 'none';
    });
});

// Filter functionality
document.getElementById('roleFilter').addEventListener('change', filterUsers);
document.getElementById('statusFilter').addEventListener('change', filterUsers);

function filterUsers() {
    const roleFilter = document.getElementById('roleFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;
    const userCards = document.querySelectorAll('.user-card');
    
    userCards.forEach(card => {
        let show = true;
        
        if (roleFilter && !card.textContent.includes(roleFilter)) {
            show = false;
        }
        
        if (statusFilter && !card.textContent.includes(statusFilter)) {
            show = false;
        }
        
        card.style.display = show ? 'block' : 'none';
    });
}

function viewUserDetails(userId) {
    // This would open a modal with detailed user information
    alert('User details view - Feature coming soon!');
}
</script>

<?php require_once '../includes/footer.php'; ?>
